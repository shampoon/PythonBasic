# Многовато переменных, расход памяти, зато выигрыш в коротком коде + в случае расширения комбинаций не придется
# много редактировать
import time


class TrafficLight:
    __color = ['red', 'yellow', 'green']

    def running(self, times=[7, 2, 7]):
        state = 'red'
        next_state = [1, 2, 0]  # список индексов для переключения на следующий цвет светофора
        color_code = ['31', '33', '32']  # список цветов текста

        while True:
            for i in range(0, len(next_state)):
                if state == TrafficLight.__color[i]:
                    print(f'\033[{color_code[i]}m \r{TrafficLight.__color[i]}', end='')
                    time.sleep(times[i])
                    state = TrafficLight.__color[next_state[i]]


t_light = TrafficLight()
t_light.running()
