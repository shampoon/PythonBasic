# Реализуйте базовый класс Car. У данного класса должны быть следующие атрибуты: speed, color, name, is_police (булево).
# А также методы: go, stop, turn(direction), которые должны сообщать, что машина поехала, остановилась, повернула
# (куда). Опишите несколько дочерних классов: TownCar, SportCar, WorkCar, PoliceCar. Добавьте в базовый класс метод
# show_speed,
# который должен показывать текущую скорость автомобиля. Для классов TownCar и WorkCar переопределите метод show_speed.
# При значении скорости свыше 60 (TownCar) и 40 (WorkCar) должно выводиться сообщение о превышении скорости.
# Создайте экземпляры классов, передайте значения атрибутов. Выполните доступ к атрибутам, выведите результат.
# Выполните вызов методов и также покажите результат.


class Car:
    speed = 0
    color = ''
    name = ''
    is_police = False
    is_going = False

    def __init__(self, color, name, is_police):
        self.color = color
        self.name = name
        self.is_police = is_police
        print(f'======================= Встречайте новый автомобиль!!! {self.name} =================================='[:96])

    def go(self, speed):
        print(f'Автомобиль {self.name} приведен в движение. Текущая скорость {self.speed} км/ч ')
        self.is_going = True
        self.speed = speed

    def stop(self):
        print(f'Автомобиль {self.name} остановлен. Текущая скорость 0 км/ч ')
        self.is_going = False
        self.speed = 0

    def turn(self, direction):
        if self.is_going:
            print(f'Автомобиль {self.name} повернул в {direction}. Текущая скорость {self.speed} км/ч ')
        else:
            print(f'АМИГО, ты забыл завести машину!')

    def show_speed(self):
        if self.speed > 90 and self.is_going:
            print(f'Автомобиль {self.name} едет со скоростью {self.speed} Скорость превышена! ')
        elif not self.is_going:
            print(f'Скорость 0 км/ч, т.к. автомобиль {self.name} остановлен')


class TownCar(Car):

    def show_speed(self):
        if self.speed > 60:
            print('Скорость превышена! ')


class SportCar(Car):
    def __init__(self, name, color):
        super().__init__(self, color, name)
        self.speed = 120
        self.is_police = False


class WorkCar(Car):

    def show_speed(self):
        if self.speed > 40:
            print('Скорость превышена! ')


class PoliceCar(Car):
    def __init__(self, color, name):
        super().__init__(self, color, name)
        self.is_police = True


my_TownCar = TownCar('yellow', 'NY taxi', False)
my_TownCar.turn('LEFT')
my_TownCar.go(59)
my_TownCar.show_speed()
my_TownCar.turn('LEFT')
my_TownCar.turn('RIGHT')
my_TownCar.speed = 79
my_TownCar.show_speed()
my_TownCar.stop()

my_SportCar = SportCar('blue', 'Subaru Legacy')
my_SportCar.show_speed()
my_SportCar.go(89)
my_SportCar.show_speed()
my_SportCar.turn('RIGHT')
my_SportCar.speed = 155
my_SportCar.show_speed()
my_SportCar.stop()

my_WorkCar = WorkCar('black', 'Toyota Camry', False)
my_WorkCar.turn('LEFT')
my_WorkCar.go(69)
my_WorkCar.show_speed()
my_WorkCar.turn('LEFT')
my_WorkCar.turn('RIGHT')
my_WorkCar.speed = 39
my_WorkCar.show_speed()
my_WorkCar.stop()

my_PoliceCar = PoliceCar('white-blue', 'Sckoda Octavia')
my_PoliceCar.turn('LEFT')
my_PoliceCar.go(69)
my_PoliceCar.show_speed()
my_PoliceCar.turn('LEFT')
my_PoliceCar.turn('RIGHT')
my_PoliceCar.speed = 39
my_PoliceCar.show_speed()
my_PoliceCar.stop()


