# Реализовать функцию my_func(), которая принимает три позиционных аргумента,
# и возвращает сумму наибольших двух аргументов


def my_func(a, b, c):
    return sum([a, b, c]) - min([a, b, c])


def my_func_args(*args):
    return sum(args) - min(args)


print(my_func(4, 5, 9))
print('======================SECOND VERSION==================')
print(my_func_args(4, 5, 9))
