# Реализовать функцию, принимающую несколько параметров, описывающих данные пользователя:
# имя, фамилия, год рождения, город проживания, email, телефон.
# Функция должна принимать параметры как именованные аргументы. Реализовать вывод данных о пользователе одной строкой


def user_info(name, surname, yob, city, email, phone):
    print(f"{name} {surname} {yob} year of born live in {city} email: {email} phone number: {phone}")


def user_info_k(**kwargs):
    return kwargs


user_info('Victor', 'Smith', 2003, 'NewYork', 'gmail@gmail.com', '+189464864863')
print('================= SECOND VERSION ========================')
print(user_info_k(name = 'Victor', surname = 'Smith', year_of_born = 2003, city = 'NewYork', email = 'gmail@gmail.com',
                  phone = '+189464864863'))
