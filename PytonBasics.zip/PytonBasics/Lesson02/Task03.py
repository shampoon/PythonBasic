# 3. Пользователь вводит месяц в виде целого числа от 1 до 12.
# Сообщить к какому времени года относится месяц (зима, весна, лето, осень). Напишите решения через list и через dict.

list_month = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october',
              'november', 'december']
dict_month = {1: 'january', 2: 'february', 3: 'march', 4: 'april', 5: 'may', 6: 'june', 7: 'july', 8: 'august',
              9: 'september', 10: 'october', 11: 'november', 12: 'december'}
num_month = int(input('Введите номер месяца: '))
print(f'По методу списка вы ввели {list_month[num_month - 1]}')
print(f'По методу словаря вы ввели {dict_month[num_month]}')
