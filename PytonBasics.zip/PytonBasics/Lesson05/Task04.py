# Необходимо написать программу, открывающую файл на чтение и считывающую построчно данные. При этом английские
# числительные должны заменяться на русские. Новый блок строк должен записываться в новый текстовый файл.
num_dict = {'One': 'Один', 'Two': 'Два', 'Three': 'Три', 'Four': 'Четыре'}
with open('text04_1.txt', 'r') as f_read:
    with open('text04_2.txt', 'w') as f_write:
        for line in f_read:
            for key, value in num_dict.items():
                if line.find(key) > -1:
                    print(line.replace(key, value), file=f_write, end='')
