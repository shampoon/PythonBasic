# Создать текстовый файл (не программно), построчно записать фамилии сотрудников и величину их окладов (не менее
# 10 строк). Определить, кто из сотрудников имеет оклад менее 20 тыс., вывести фамилии этих сотрудников. Выполнить
# подсчет средней величины дохода сотрудников.
my_dict = {}
cnt = 0
av_salary = 0
with open('text03.txt', 'r') as my_file:
    for line in my_file:
        if float(line.split()[1]) < 20000:
            my_dict[line.split()[0]] = float(line.split()[1])
        cnt += 1
        av_salary += float(line.split()[1])
print(f'Средний оклад равен {(av_salary / cnt) :.2f}')
print('Список сотрудников с окладом меньше 20 000:')
for key in my_dict:
    print(key)

