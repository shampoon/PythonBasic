# Создать программно файл в текстовом формате, записать в него построчно данные, вводимые пользователем.
# Об окончании ввода данных свидетельствует пустая строка.


import os


with open('text01.txt', 'w', encoding='UTF-8') as my_file:
    while True:
        tmp_str = input('Введите пожалуйста данные для записи в файл: ')
        if tmp_str == '':
            print(f'Данные записаны в файл {os.getcwd() + my_file.name}')
            break
        else:
            print(tmp_str, file=my_file)
