while True:
    ans = input('Хотите использовать файл из первого задания? (y/n)')
    if ans != 'y' or ans != 'n':
        break
if ans == 'y':
    file_name = 'text01.txt'
else:
    file_name = 'text02.txt'
print(f'Подсчет будет производится в файле {file_name}')
with open(file_name, 'r') as my_file:
    cnt = 0
    for lines in my_file.readlines():
        cnt += 1
        print(f'Строка №{cnt} содержит {len(lines.split())} слов')
    print(f'В файле {cnt} строк')
