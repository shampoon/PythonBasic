import json

firm_dict = {}
cnt = 0
av_profit = 0
with open('text07.txt', 'r') as my_file:
    for line in my_file.readlines():
        print(line.split())
        name, proceeds, cost = line.split()[0], int(line.split()[2]), int(line.split()[3])
        profit = proceeds - cost
        if profit > 0:
            cnt += 1
            av_profit += profit
        firm_dict[name] = profit
# print(firm_dict)
av_profit = av_profit / cnt
av_profit_dict = {'average_profit': av_profit}
# print(av_profit_dict)
result_list = [firm_dict, av_profit_dict]
# print(result_list)
with open('text07.json', 'w') as f_json:
    json.dump(result_list, f_json, sort_keys=True, indent=4, ensure_ascii = False)
