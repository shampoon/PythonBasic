seconds = int(input('Please, input seconds: '))
if seconds > 86400 or seconds < 0:
    print('Incorrect value. Exit')
else:
    hours = seconds // 3600
    minets = (seconds % (hours * 3600)) // 60
    secs = seconds % 3600 - minets * 60
    print(f'{hours}:{minets}:{secs}')
