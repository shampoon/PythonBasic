num = int(input('Please, input positive number: '))
maxim = 0
while num != 0:
    maxim = maxim if maxim > num % 10 else num % 10
    num = num // 10
print(maxim)
