#Запросите у пользователя значения выручки и издержек фирмы.
# Определите, с каким финансовым результатом работает фирма (прибыль — выручка больше
# издержек, или убыток — издержки больше выручки). Выведите соответствующее сообщение.
# Если фирма отработала с прибылью, вычислите рентабельность выручки (соотношение прибыли к выручке).
# Далее запросите численность сотрудников фирмы и определите прибыль фирмы в расчете на одного сотрудника.
proceeds = int(input('Please, input proceeds of company: '))
costs = int(input('Please, input costs of company: '))
if proceeds > costs:
    print('Take my congratulations!!! Your company is makes a profit')
    print('Profitability of your company is ', (proceeds - costs)*100/costs, ' %')
    staff = int(input('Please, input staff count in your company: '))
    print('Profit for one personnel = ', (proceeds - costs) / staff)
else:
    print('You need to work on your company ...')
