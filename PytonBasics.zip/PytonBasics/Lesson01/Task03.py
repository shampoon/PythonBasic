num = input('User, please input the degit')
if len(num) == 1 and num.isnumeric():
    print('Your summ = ', int(num) + int(num + num) + int(num+num+num))
else:
    print(num, ' - it is not a digit')
