
from sys import argv

name_script, worked_hours, price_for_hour, bonus = argv
print(f'Salary of worker = {int(worked_hours) * int(price_for_hour) + int(bonus)}')
