class Cell:
    def __init__(self, cnt):
        self.cnt = cnt

    def __add__(self, other):
        return Cell(self.cnt + other.cnt)

    def __sub__(self, other):
        return self.cnt - other.cnt if self.cnt - other.cnt > -1 else 0

    def __mul__(self, other):
        return Cell(self.cnt * other.cnt)

    def __truediv__(self, other):
        return Cell(self.cnt // other.cnt)

    def __str__(self):
        return str(self.cnt)

    def make_order(self, frmt):
        return ('*' * frmt + '\n') * (self.cnt // frmt) + '*' * (self.cnt % frmt)


my_cell1 = Cell(25)
my_cell2 = Cell(4)
print(f'add result:  {my_cell1 + my_cell2}')
print(f'sub result:  {my_cell1 - my_cell2}')
print(f'mull result:  {my_cell1 * my_cell2}')
print(f'truediv result:  {my_cell1 / my_cell2}')
print(my_cell1.make_order(6))
