class Data:

    def __init__(self, data):
        self.data = data
        self.ints = []

    @classmethod
    def string_to_int(cls, obj):
        return list(map(int, Data(obj).data.split('-')))

    @staticmethod
    def validation(param):
        if param[1] in [1, 3, 5, 7, 8, 10, 12] and param[0] in range(1, 32) \
            or param[1] in [4, 6, 9, 11] and param[0] in range(1, 31) \
            or param[1] == 2 and param[0] in range(1, 29) and param[2] % 4 != 0 \
            or param[1] == 2 and param[0] in range(1, 30) and param[2] % 4 == 0:
            print('Day is ok.', end='   ')
        else:
            print("Day is't ok.", end='   ')
        if param[1] in range(1,13):
            print('Month is ok.', end='   ')
        else:
            print("Month is't ok.", end='   ')
        if param[2] >= 0:
            print('Year is ok.', end='   ')
        else:
            print("Year is't ok.", end='   ')


my_data = Data('12-12-2017')
print(Data.string_to_int(my_data.data))
my_data.validation([29, 12, 2002])
