class MyError(Exception):

    def __init__(self, text):
        self.text = text


try:
    a = int(input('Введите делимое: '))
    b = int(input('Введите делитель: '))
    if b == 0:
        raise MyError('Ошибка: Деление на ноль!')
except ValueError:
    print('Вы ввели не число!')
except MyError as err:
    print(err)
else:
    print(a / b)
