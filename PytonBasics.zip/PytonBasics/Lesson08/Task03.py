class MyError(Exception):

    def __init__(self, text):
        self.text = text


my_list = []
print('Сейчас начнется непрерывный ввод чисел для составления списка. Для выхода введите #')
while True:
    inp = input('Введите число: ')
    try:
        if inp.isdigit():
            my_list.append(int(inp))
        else:
            raise MyError('Вы ввели не число!')
    except MyError as err:
        print(err)
    if inp == '#':
        break
print(f'Результат: {my_list}')
