class MyStock:
    legacy = {}

    @classmethod
    def add_to_legacy(cls, inst, cnt):
        if cls.legacy.get(inst) is None:
            cls.legacy[inst] = cnt
        else:
            cls.legacy[inst] += cnt

    def __init__(self, name):
        self.name = name
        self.stock = {}

    def add_to_stock(self, inst, cnt):
        if self.stock.get(inst) is None:
            self.stock[inst] = cnt
        else:
            self.stock[inst] += cnt

    def enterance_to_stock(self, inst, cnt):
        self.add_to_legacy(inst, cnt)
        self.add_to_stock(inst, cnt)

    def move_from_stock_to_stock(self, other, inst, cnt):
        if type(cnt) == type(2):
            print(f'Перемещение на склад {other.name} со склада {self.name} техники {inst} в количестве {cnt}')
            if self.stock.get(inst) is None:
                print('Перемещение невозможно. Оборудование на складе источника отсутствует')
            elif self.stock.get(inst) < cnt:
                print(f'Вы хотите переместить {cnt} едениц оборудования {inst}. '
                      f'На складе источнике есть только {self.stock.get(inst)}')
            else:
                self.stock[inst] -= cnt
                other.add_to_stock(inst, cnt)
        else:
            print('В количество перадано не число! Будьте внимательны')

    def __str__(self):
        print('Техника в ' + self.name + ':')
        res = ''
        for key, val in self.stock.items():
            tab = " " * (25 - len(key)) if len(key) < 25 else ''
            res = res + f'{key}:{tab} {val}' + '\n'
        return 'Склад пуст \n' if res == '' else res


class OfficeEquipment:

    def __init__(self, name, power, weight):
        self.name = name
        self.power = power
        self.weight = weight
        self.stock = None


class Printer(OfficeEquipment):
    def __init__(self, name, power, weight, page_per_minute, print_type='Laser', color=True):
        super().__init__(name, power, weight)
        self.page_per_minute = page_per_minute
        self.print_type = print_type
        self.color = color


class Scanner(OfficeEquipment):
    def __init__(self, name, power, weight, page_per_minute, resolution):
        super().__init__(name, power, weight)
        self.page_per_minute = page_per_minute
        self.resolution = resolution


class Coper(OfficeEquipment):
    def __init__(self, name, power, weight, page_per_minute, resolution, print_type='Laser', color=True):
        super().__init__(name, power, weight)
        self.page_per_minute = page_per_minute
        self.print_type = print_type
        self.color = color
        self.resolution = resolution


stock1 = MyStock('Склад №1')  # Создали склад предприятия
department1 = MyStock('Отдел разработки на Python')  # создали отдел (как склад) для учета оборудования в отделе
department2 = MyStock('Отдел разработки на С#')
printer1 = Printer('HP 1358', 75, 7, 12)  # создали модель принтера
scanner1 = Scanner('Canon M358', 40, 2, 2, 720)  # создали модель сканера
coper1 = Coper('Coyasera AlphaTask 358', 120, 35, 32, 1890, color=False)
stock1.enterance_to_stock(coper1.name, 2)  # в предприяте зашел новое оборудование - регистрируем его на склад №1
stock1.enterance_to_stock(printer1.name, 5)
stock1.enterance_to_stock(scanner1.name, 2)

print(stock1)  # посмотрели стостояние склада

print(department1)  # посмотрели стостояние склада
stock1.move_from_stock_to_stock(department1, printer1.name, 2) # перемещение техники со склада в отдел
print(department1)
print(stock1)  # посмотрели стостояние склада
print('==================================================================================================')
stock1.move_from_stock_to_stock(department2, scanner1.name, 2)
stock1.move_from_stock_to_stock(department2, coper1.name, 1)
stock1.move_from_stock_to_stock(department2, printer1.name, 1)
print(department2)
